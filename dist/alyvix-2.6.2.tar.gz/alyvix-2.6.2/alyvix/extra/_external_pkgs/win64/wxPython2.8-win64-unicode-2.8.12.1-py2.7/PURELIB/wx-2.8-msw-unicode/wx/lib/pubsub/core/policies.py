'''

:copyright: Copyright 2006-2009 by Oliver Schoenborn, all rights reserved.
:license: BSD, see LICENSE.txt for details.

'''

msgProtocolTransStage = None

msgDataProtocol    = 'kwargs'
msgDataArgName     = None
senderKwargNameAny = False
